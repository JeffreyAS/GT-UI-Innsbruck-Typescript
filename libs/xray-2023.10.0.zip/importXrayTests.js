const _ = require("lodash"),
    FormData = require("form-data"),
    axios = require("axios").default,
    fs = require("fs"),
    logUtil = require("./util/logUtilities.js"),
    eol = require("eol"),
    xrayUtilities = require("./util/xrayUtilities.js"),
    cucumberSyncOutput = "../CucumberSyncOutput.log";

/**
 * imports every scenario from each feature file into jira as an Xray Test
 * scenario name must match jira summary
 */
async function importCucumberTestsToJira(dir) {

    fs.writeFile(cucumberSyncOutput, '', function(e) {if(e) throw  e;});
    const authorizationToken = await xrayUtilities.createAuthenticationToken();
    return new Promise((resolve, reject) => {
        axios.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
        axios.defaults.headers.common["Authorization"] = "Bearer " + authorizationToken;
        if(authorizationToken == undefined){
            reject(new Error("Error Getting AuthToken for XRay Communication.!"));
        }
        // Find all the .feature files...
        xrayUtilities.walk(dir, "feature", function (err, files) {
            if (err){
                console.error(logUtil.getCurrentDateTime() + ' Error with the feature files dir: \n' + err);
                reject(err);
            }else{
                let index = 1;
                const numberOfFiles = files.length;
                var stream = fs.createWriteStream(cucumberSyncOutput, {flags:'a'});
                stream.write("\n Created/Updated following XRay Tests: " + logUtil.getCurrentDateTime() + "\n");
                console.log(logUtil.getCurrentDateTime() + " Performing XRAY Cucumber Scenarios Sync...\n");
                console.log(logUtil.getCurrentDateTime() + " The following XRAY tests are being created/updated");
                _.each(files, function (file) {
                    xrayUtilities.createTestCaseInfoFile(file).then(function(testInfoFile) {
                        //console.log("Processing: " + JSON.stringify(file) + "with " + testInfoFile);
                        // for each feature file use Xray api to post each test to Jira cloud
                        let form_data = new FormData();
                        form_data.append("file", fs.createReadStream(file));
                        form_data.append("testInfo", fs.createReadStream(testInfoFile));
                        axios.post("https://xray.cloud.getxray.app/api/v1/import/feature?projectKey=" + global.projectId , form_data, {
                            headers: form_data.getHeaders()
                        }).then((response) => {
                            var importResultsSize = Object.keys(response.data.updatedOrCreatedTests).length;
                            let filterData = "";
                            for (let i=0; i < importResultsSize; i++) {
                                axios.get("https://xray.cloud.getxray.app/api/v1/export/cucumber?keys=" + response.data.updatedOrCreatedTests[i].key, {
                                }).then((response) => {
                                    filterData = response.data;

                                    let lines = eol.split(filterData)
                                    lines.forEach(function(line) {

                                        switch(true) {
                                            case(_.includes(line, "TEST_")):
                                                console.log(line);
                                                stream.write(line + "\n");
                                                break;
                                            case(_.includes(line, "Scenario:")):
                                                console.log(line);
                                                stream.write(line + "\n");
                                                break;
                                            case(_.includes(line, "Scenario Outline:")):
                                                console.log(line);
                                                stream.write(line + "\n");
                                                break;
                                        }
                                    })
                                }).catch((error) => {

                                });
                            }
                            if (fs.existsSync(testInfoFile)) {
                                fs.unlinkSync(testInfoFile);
                            }
                            if (index === numberOfFiles) {
                                resolve(response.data);
                            }
                            index++;
                        }).catch((error) => {
                            console.log(logUtil.getCurrentDateTime() + " Syncing tests in Jira failed..");
                            logUtil.logHttpError(error);
                            reject(error);
                        });
                    }).catch(function(e){  reject(console.error(e)); });
                })
            }
        });
    });
}

module.exports = { importCucumberTestsToJira };



