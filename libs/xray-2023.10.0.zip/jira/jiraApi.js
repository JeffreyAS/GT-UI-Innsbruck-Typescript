const _ = require("lodash"),
    axios = require("axios").default,
    process = require("process"),
    logUtil = require("./../util/logUtilities.js"),
    jiraAPIUrl = process.env.JIRA_API_URL,
    jirAPIUser = process.env.JIRA_API_USER,
    jirAPIToken = process.env.JIRA_API_TOKEN,
    jiraAuth = process.env.JIRA_API_USER + ":" + process.env.JIRA_API_TOKEN;

/**
 * Checks and verifies the Jira connection
 * @returns {Promise<any>}
 */
async function verifyJiraConnection() {
  try {

    const axiosInstance = axios.create({
      baseURL: jiraAPIUrl + '/rest/api/3/project/',
      auth: {
        jirAPIUser,
        password: jirAPIToken,
      },
    });

    // Make a GET request to the Jira REST API to fetch server information
    const response = await axiosInstance.get('/');

    // If the request is successful, Jira is reachable
    console.log(logUtil.getCurrentDateTime() + ' Jira connection verified successfully!');
    return response.data;
  } catch (error) {
    // If there's an error, it indicates a problem with the connection
    console.error(logUtil.getCurrentDateTime() + ' Jira connection failed:', error.message);
  }
}

/**
 * Adds component to to specified jira
 */
async function updateJiraComponent(bodyData, jiraID) {
  const options = {
    method: "PUT",
    url: jiraAPIUrl + "/rest/api/3/issue/" + jiraID,
    headers: {
      "Authorization": `Basic ${Buffer.from(
          jiraAuth
      ).toString("base64")}`,
      "Accept": "application/json",
      "Content-Type": "application/json"
    },
    data: bodyData
  };
  try {
    const response = await axios(options);
    // console.log(
    //     `Response: ${response.status} ${response.statusText} - component updated for ${jiraID}`
    // );
    console.log(logUtil.getCurrentDateTime() + " XRAY tests are updated in Jira..");
    return response;
  } catch (error){
    console.log(logUtil.getCurrentDateTime() + " Updating Jira components failed..");
    logUtil.logHttpError(error);
  }
}

/**
 * returns jira ID by searching for its summary in the project
 */
async function getJiraIdBySummary(bodyData, jiraSummary) {
  const options = {
    method: "POST",
    url: jiraAPIUrl + "/rest/api/3/search",
    headers: {
      "Authorization": `Basic ${Buffer.from(
          jiraAuth
      ).toString("base64")}`,
      "Accept": "application/json",
      "Content-Type": "application/json"
    },
    data: bodyData
  };
  let issueFound = true,
      issues = [];
  try {
    const response = await axios(options);
    if (response.data.issues.length === 0){
      issueFound = false;
      throw new Error("No tests found for " + jiraSummary);
    }else if (response.data.issues.length === 1){
      return response.data.issues["0"].key;
    }else {
      issueFound = false;
      _.each(response.data.issues, function (issue) {
        if (issue.fields.summary === jiraSummary){
          issueFound = true;
          issues.push(issue.key);
        }
      });
      if (!issueFound){
        throw new Error("More than one test found for " + jiraSummary);
      }else {
        if (issues.length === 1) {
          return issues[0];
        } else {
          issueFound = false;
          throw new Error("More than one test found for " + jiraSummary);
        }
      }
    }
  } catch (error){
    console.log(logUtil.getCurrentDateTime() + " Getting Jira ID by summary failed..");
    await logUtil.logHttpError(error);
  }
}

module.exports = {
  updateJiraComponent,
  getJiraIdBySummary,
  verifyJiraConnection
};