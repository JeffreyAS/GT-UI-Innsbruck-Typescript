var fs = require('fs');
var callerId = require('caller-id');

/**
 * Utility method to log http errors meaningfully
 * By default logs the whole error object to rootDir/debug.log.
 * Log includes caller method name.
 * @param err       Error Object
 */
async function logHttpError(err) {
    var caller = callerId.getData();
    try{
        if(err.hasOwnProperty('response')){
            let response = err.response;
            console.error('Response Status: ' + response.status + ' ' + response.statusText);
            if(response.hasOwnProperty('data')){
                console.error(response.data);
            }else{
                console.error(response);
            }
        }else{
            console.error(err);
        }
        fs.appendFileSync("../debug-xray.log",JSON.stringify(caller, null , 1) + "\n" + JSON.stringify(err, null , 1), 'utf8');
        return;
    }catch(err){
        console.error('Error Processing Http log');
        console.error(err);
    }
};

function getCurrentDateTime() {
    try {
        const date = new Date();

        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');

        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    } catch {
        console.error('Unable to print current datetime');
    }
}

module.exports = {
    logHttpError,
    getCurrentDateTime
};



