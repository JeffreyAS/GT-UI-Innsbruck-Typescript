const fs = require('fs')
var jiraids = [];
var scenarioNames = [];
var cucumberSyncOutput = './../CucumberSyncOutput.log';
var logUtil = require("./logUtilities.js");

async function fetchJiraIdsToBeImported() {

    read(cucumberSyncOutput, function (data) {
        for (var id in data) {
            if (data[id].includes('@TEST')) {
                jiraids.push(data[id].split(' ')[0]);
            } else if (data[id].includes('Scenario: ')) {
                scenarioNames.push(data[id].split('Scenario: ')[1].split("\n")[0]);
            } else if (data[id].includes('Scenario Outline: ')) {
                scenarioNames.push(data[id].split('Scenario Outline: ')[1].split("\n")[0]);
            }
        }
        console.log(logUtil.getCurrentDateTime() + " Starting to import test executions in XRAY... \n");
        console.log(logUtil.getCurrentDateTime() + " Jira IDs for which test executions are imported in XRAY: \n" + jiraids + "\n");
    });

}

async function updateReportWithJiraIds(report) {

    fs.readFile(report, function read(err, data) {
        if (err) {
            throw err;
        }
        const content = data.toString();

        updateReport(content, report);   // Or put the next step in a function and invoke it
    });

}

function read(file, cb) {
    fs.readFile(file, 'utf8', function(err, data) {
        if (!err) {
            cb(data.toString().split('\n\t'))
        } else {
            console.log(err)
        }
    });
}

function updateReport(content, report) {

    const data = JSON.parse(content);

    for(let i=0; i < data.length; i++) {
        for (let j = 0; j < data[i].elements.length; j++) {
            for (let count = 0; count < jiraids.length; count++) {
                if (data[i].elements[j].type != 'background') {
                    if (data[i].elements[j].id.includes(scenarioNames[count])) {
                        data[i].elements[j].tags.push({"name": "" + jiraids[count] + ""});
                        break;
                    }
                }
            }
        }
    }

    fs.writeFile(report, JSON.stringify(data), 'utf8', function (err) {
        if (err) return console.log(err);
        console.log(logUtil.getCurrentDateTime() + " Cucumber JSON Report compatible with XRAY is updated..." + "\n");
    });
}

module.exports = {
    fetchJiraIdsToBeImported,
    updateReportWithJiraIds
};
