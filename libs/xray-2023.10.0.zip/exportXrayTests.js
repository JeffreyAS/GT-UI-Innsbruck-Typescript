const _ = require("lodash"),
    axios = require("axios").default,
    fs = require("fs"),
    logUtil = require("./util/logUtilities.js"),
    xrayUtilities = require("./util/xrayUtilities.js"),
    cucumberSyncOutput = "../CucumberSyncOutput.log",
    url = "https://xray.cloud.getxray.app/api/v1/export/cucumber?filter=" + global.filterId,
    AdmZip = require('adm-zip');

/**
 * exports cucumber tests from jira to cucumberfiles folder
 */
async function exportCucumberTestsFromJira() {

    fs.writeFile(cucumberSyncOutput, '', function(e) {if(e) throw  e;});
    const authorizationToken = await xrayUtilities.createAuthenticationToken();
    axios.defaults.headers.post["Content-Type"] = "application/json";
    axios.defaults.headers.common["Authorization"] = "Bearer " + authorizationToken;
    if(authorizationToken == undefined){
        reject(new Error("Error Getting AuthToken for XRay Communication.!"));
    }
    return new Promise((resolve, reject) => {
        axios.get(url, {
            responseType: 'arraybuffer',
        }).then((response) => {

            var zip = new AdmZip(response.data);
            var zipEntries = zip.getEntries();

            for (var i = 0; i < zipEntries.length; i++) {
                console.log("Unimplemented features: " + "\n");
                console.log(zip.readAsText(zipEntries[i]));
            }
            zip.extractAllTo('../../../xraysync', true);
            console.log("The unimplemented feature files are availabe here: xraysync/" + zipEntries[0].name);
        }).catch((error) => {
            console.log(logUtil.getCurrentDateTime() + " Exporting Cucumber tests failed.");
            logUtil.logHttpError(error);
            reject(error);
        });
    });
}

module.exports = { exportCucumberTestsFromJira };