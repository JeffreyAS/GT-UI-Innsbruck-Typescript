global.projectId = process.argv.slice(2)[0];
global.featureDir = process.argv.slice(2)[1];
const importXrayTests = require("./../importXrayTests.js"),
      cucumberFeaturesDir = "../../../" + global.featureDir;

  // import the cucumber test into jira to sync them with any xray tests create prior to implementation
  importXrayTests.importCucumberTestsToJira(cucumberFeaturesDir).then(function () {
  }).catch(function(e){ process.exit(1); });
